﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace MitigramTrainSimTests
{
    public class TrainTests
    {

        [Fact]
        public void SomeTest() {
            Assert.False(true);
        }

    }
}

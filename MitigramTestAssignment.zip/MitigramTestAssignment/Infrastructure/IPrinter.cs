﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Infrastructure
{
    public interface IPrinter
    {
        void Print(string s);
        void PrintLine(string s);
        void PrintNewline();
    }
}

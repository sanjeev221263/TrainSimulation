﻿using MitigramTestAssignment.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Infrastructure
{
    public class ConsolePrinter : IPrinter
    {
        public void Print(string s)
        {
            Console.Write("\r{0}", s.PadRight(75));
        }

        public void PrintLine(string s)
        {
            Console.WriteLine(s);
        }

        public void PrintNewline()
        {
            Console.WriteLine();
        }
    }
}

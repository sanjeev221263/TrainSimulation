﻿using MitigramTestAssignment.Domain;
using MitigramTestAssignment.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace MitigramTestAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            var printer = new ConsolePrinter();
            PrintMenu(printer);
            
            var simTime = new SimulationTime();

            var track = new Track();
            track.AddTrainStation(new TrainStation(distanceKmFromLastStation: 1));
            track.AddTrainStation(new TrainStation(distanceKmFromLastStation: 3));
            track.AddTrainStation(new TrainStation(distanceKmFromLastStation: 2));
            
            using (var train = new Train(240, printer, simTime))
            {
                var conductor = TrainConductor.BoardTrain(train, printer, simTime);
                conductor.GuideTrainOntoTrack(track);
                conductor.TakeTrainOnATestRun();
                conductor.DrinkCoffeAndWaitForCommands();
            }

            printer.PrintNewline();
            printer.PrintLine("Simulation completed. Press any key to exit");

            Console.ReadLine();
        }

        private static void PrintMenu(IPrinter printer)
        {
            printer.PrintLine("***** Welcome to Mitigram Train Sim ******");
            printer.PrintLine("esc = quit simulation");
            printer.PrintLine("ax = accelerate train to x percent of capacity");
            printer.PrintLine("dx = decelerate train to x percent of capacity");
            printer.PrintLine("s = stop/start the train");
            printer.PrintLine("******************************************");
        }
    }

}

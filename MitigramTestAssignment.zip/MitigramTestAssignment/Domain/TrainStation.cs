﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Domain
{
    public sealed class TrainStation
    {
        public double DistanceKmFromLastStation { get; private set; }

        public TrainStation(double distanceKmFromLastStation)
        {
            this.DistanceKmFromLastStation = distanceKmFromLastStation;
        }

    }
}

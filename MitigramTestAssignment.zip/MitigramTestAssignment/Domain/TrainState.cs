﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Domain
{
    public enum TrainState
    {
        Unknown,
        Stopped,
        Accelerating,
        Decelerating,
        TargetSpeed,
        FullSpeed
    }
}

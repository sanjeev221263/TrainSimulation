﻿using MitigramTestAssignment.Helpers;
using MitigramTestAssignment.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace MitigramTestAssignment.Domain
{
    public sealed class TrainConductor
    {
        private IPrinter _printer;
        private Train _train;
        private SimulationTime _simTime;
        public bool IsTrainInOperation { get; private set; }
        public TimeSpan TrainTimeToFullAcceleration { get; private set; }
        public TimeSpan TrainTimeToFullStop { get; private set; }
        public bool IsTrainStopped => _train.CurrentState == TrainState.Stopped;
        private Track _track;

        private TrainConductor(Train train, IPrinter printer, SimulationTime simTime)
        {
            _train = train;
            _printer = printer;
            _simTime = simTime;
            IsTrainInOperation = true;
        }

        public void TakeTrainOnATestRun()
        {
            IsTrainInOperation = false;
            _printer.PrintLine("Starting test run!");

            var time = _simTime.Total;
            _train.Start();
            _train.AccelerateToCapacity(100);

            while (_train.CurrentState != TrainState.FullSpeed)
            {
                Thread.Sleep(100);
            }

            TrainTimeToFullAcceleration = _simTime.Total - time;
            time = _simTime.Total;

            _train.DecelerateToCapacity(0);
            while (_train.CurrentState != TrainState.Stopped)
            {
                Thread.Sleep(100);
            }
            TrainTimeToFullStop = _simTime.Total - time;
            IsTrainInOperation = true;

            _printer.PrintLine("Test run complete. Conductor learned that the train can come to full stop from full capacity in " + TrainTimeToFullStop.TotalSeconds + "s");
        }

        internal void GuideTrainOntoTrack(Track track)
        {
            _train.InputTrackDataIntoTrainSystem(track);
        }

        public static TrainConductor BoardTrain(Train train, IPrinter printer, SimulationTime time)
        {
            if (train == null)
            {
                throw new ArgumentException("The conductor is no one without a train!");
            }

            return new TrainConductor(train, printer, time);
        }

        public void DrinkCoffeAndWaitForCommands()
        {
            _printer.PrintLine("Conductor is drinking coffee and waiting for your commands!");

            var _buffer = new BufferBlock<ICommand>();
            var consumer = ConsumeAsync(_buffer);
            ReadCommands(_buffer);

            consumer.Wait();
        }

        private void ReadCommands(ITargetBlock<ICommand> target)
        {
            if (!IsTrainInOperation)
            {
                return;
            }

            string currentStr = "";
            while (!Console.KeyAvailable)
            {
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Escape)
                {
                    break;
                }
                currentStr += key.KeyChar;
                var commandImpl = CommandFactory.CreateNewCommand(currentStr, key.Key);
                if (commandImpl != null)
                {
                    target.Post(commandImpl);
                    currentStr = "";
                }
            }

            target.Complete();
        }

        private async Task ConsumeAsync(ISourceBlock<ICommand> source)
        {
            while (await source.OutputAvailableAsync())
            {
                var cmd = source.Receive();
                if (cmd != null)
                {
                    ShoutCommand(cmd);
                }
            }
        }

        public void ShoutCommand(ICommand cmd)
        {
            cmd.Execute(this);
        }

        internal void StartTrain()
        {
            _train.Start();
        }

        internal void StopTrain()
        {
            _printer.PrintNewline();
            _printer.PrintLine("Everyone hold on! I'm stopping the train");
            _train.Stop();
        }

        internal void AccelerateByPercent(double by)
        {
            _train.AccelerateToCapacity((_train.TargetSpeed / _train.MaxCapacity) + by);
        }

        internal void DeceleratByPercent(double by)
        {
            _train.DecelerateToCapacity((_train.TargetSpeed / _train.MaxCapacity) - by);
        }

        internal void AccelerateToCapacity(double target)
        {
            _train.AccelerateToCapacity(target);
        }

        internal void DecelerateToCapacity(double target)
        {
            _train.DecelerateToCapacity(target);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Domain.Commands
{
    public class AccelerateCommand : ICommand
    {
        public double _target;

        public AccelerateCommand(double target)
        {
            _target = target;
        }

        public void Execute(TrainConductor conductor)
        {
            conductor.AccelerateToCapacity(_target);
        }
    }
}

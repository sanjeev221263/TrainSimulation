﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Domain.Commands
{
    public class DecelerateByCommand : ICommand
    {
        public double _by;

        public DecelerateByCommand(double by)
        {
            _by = by;
        }

        public void Execute(TrainConductor conductor)
        {
            conductor.DeceleratByPercent(_by);
        }
    }
}

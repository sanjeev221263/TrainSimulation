﻿using MitigramTestAssignment.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Domain
{
    public sealed class Train : IDisposable
    {
        public int MaxCapacity { get; private set; }
        private TrainState _currentState;
        public TrainState CurrentState
        {
            get
            {
                return _currentState;
            }
            private set
            {
                PreviousState = _currentState;
                _currentState = value;
            }
        }
        private TrainState PreviousState { get; set; }
        private CancellationTokenSource _stopSource = new CancellationTokenSource();
        private Task _trainTask;
        private IPrinter _printer;
        private AccelerateBehavior _acceleration;
        private SimulationTime _simTime;
        
        private double _distanceCoveredKm;
        private TrainStation _nextStation;
        private double _distanceToNextStation;

        public double TargetSpeed { get; private set; }
        public double CurrentSpeed { get; internal set; }

        private Track _track;

        public Train(int maxCapacity, IPrinter printer, SimulationTime simTime)
        {
            MaxCapacity = maxCapacity;
            CurrentState = TrainState.Stopped;
            _printer = printer;
            _simTime = simTime;
            _acceleration = new AccelerateBehavior(TargetSpeed, 0, 0.05, 1);

            _trainTask = Task.Factory.StartNew(() =>
            {
                while (!_stopSource.IsCancellationRequested)
                {
                    var fps = 1 / 33d;
                    var frameTime = TimeSpan.FromMilliseconds(1000 * fps);
                    _distanceCoveredKm += CurrentSpeed * frameTime.TotalHours;

                    Update();
                    RenderTo(_printer);

                    Thread.Sleep((int)(1000 * fps));
                    _simTime.Total = _simTime.Total.Add(frameTime);
                    PreviousState = CurrentState;


                }
            }, _stopSource.Token);

        }

        internal void InputTrackDataIntoTrainSystem(Track track)
        {
            _track = track;
        }

        public void Start()
        {
            AccelerateToCapacity(1.0);
            _printer.PrintLine("The train is leaving the platform!");
        }

        public void Stop()
        {
            DecelerateToCapacity(0);
        }

        public void AccelerateToCapacity(double targetPercent)
        {
            TargetSpeed = MaxCapacity * (targetPercent / 100);
            if (_acceleration._increaseFactor < 0)
            {
                _acceleration._increaseFactor = -_acceleration._increaseFactor;
            }
            _acceleration._maxVelocity = TargetSpeed;
            CurrentState = TrainState.Accelerating;
        }

        public void DecelerateToCapacity(double targetPercent)
        {
            TargetSpeed = MaxCapacity * (targetPercent / 100);
            if (_acceleration._increaseFactor > 0)
            {
                _acceleration._increaseFactor = -_acceleration._increaseFactor;
            }
            _acceleration._maxVelocity = TargetSpeed;
            CurrentState = TrainState.Decelerating;
        }

        private void IncreaseBreakCapacity() {
            if (_currentState == TrainState.Decelerating) {
                _acceleration._increaseFactor *= 2;
            }
        }
        
        private void Update()
        {
            if (CurrentState == TrainState.Accelerating)
            {
                _acceleration.Translate(_simTime, this);
                if (CurrentSpeed == MaxCapacity)
                {
                    CurrentState = TrainState.FullSpeed;
                }
                else if (CurrentSpeed == TargetSpeed)
                {
                    CurrentState = TrainState.TargetSpeed;
                }
            }
            if (CurrentState == TrainState.Decelerating)
            {
                _acceleration.Translate(_simTime, this);
                if (CurrentSpeed <= 0.01)
                {
                    CurrentState = TrainState.Stopped;
                }
                else if (CurrentSpeed <= TargetSpeed)
                {
                    CurrentState = TrainState.TargetSpeed;
                }
            }

            if (_nextStation == null) {
                _nextStation = _track.TrainStations.First();
            }
            //TODO TASK 3: ADD IMPLEMENTATION FOR CALCULATING DISTANCE TO THE NEXT STATION
            _distanceToNextStation = _nextStation.DistanceKmFromLastStation;
            
        }

        private void RenderTo(IPrinter printer)
        {
            if (PreviousState == CurrentState && CurrentState == TrainState.Stopped)
            {
                return;
            }

            if (PreviousState != CurrentState)
            {
                printer.PrintNewline();
            }

            switch (CurrentState)
            {
                case TrainState.Stopped:
                    printer.PrintLine("Train is stopped. Distance covered: " + _distanceCoveredKm.ToString("N4") + " km" + ". "+ _distanceToNextStation + " km to next station");
                    break;
                case TrainState.Accelerating:
                    printer.Print("Accelerating to " + TargetSpeed.ToString("N2") + " km/h, current speed " + CurrentSpeed.ToString("N2") + " km/h. Distance covered: " + _distanceCoveredKm.ToString("N4") + " km" + ". " + _distanceToNextStation + " km to next station");
                    break;
                case TrainState.Decelerating:
                    printer.Print("Decelerating to " + TargetSpeed.ToString("N2") + " km/h, current speed " + CurrentSpeed.ToString("N2") + " km/h. Distance covered: " + _distanceCoveredKm.ToString("N4") + " km" + ". " + _distanceToNextStation + " km to next station");
                    break;
                case TrainState.TargetSpeed:
                    printer.Print("Running at target capacity " + TargetSpeed.ToString("N2") + " km/h. Distance covered: " + _distanceCoveredKm.ToString("N4") + " km" + ". " + _distanceToNextStation + " km to next station");
                    break;
                case TrainState.FullSpeed:
                    printer.Print("Running at full capacity: " + CurrentSpeed + " km/h. Distance covered: " + _distanceCoveredKm.ToString("N4") + " km" + ". " + _distanceToNextStation + " km to next station");
                    break;
                default:
                    break;
            }
        }

        #region IDisposable Members

        /// <summary>
        /// Internal variable which checks if Dispose has already been called
        /// </summary>
        private bool _disposed;

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _stopSource.Cancel();
                _stopSource.Dispose();
            }

            _disposed = true;
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            // Call the private Dispose(bool) helper and indicate 
            // that we are explicitly disposing
            this.Dispose(true);

            // Tell the garbage collector that the object doesn't require any
            // cleanup when collected since Dispose was called explicitly.
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}

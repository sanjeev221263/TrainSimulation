﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment.Domain
{
    public class Track
    {
        public LinkedList<TrainStation> TrainStations { get; set; }

        public Track()
        {
            TrainStations = new LinkedList<TrainStation>();
        }

        public void AddTrainStation(TrainStation station) {
            TrainStations.AddLast(station);
        }
    }
}

using MitigramTestAssignment.Domain;

namespace MitigramTestAssignment
{
    public class AccelerateBehavior 
    {
        public double _increaseFactor;
        public double _maxVelocity;
        public double _minVelocity;
        public int _loops;
        public TimeTrigger Trigger;
        private int _currentLoop;
        
        public bool IsCompleted
        {
            get
            {
                return false;
            }
        }
        
        private Train _train;

        public AccelerateBehavior(double maxVelocity, double minVelocity, double increaseFactor, int loops)
        {
            _increaseFactor = increaseFactor;
            _maxVelocity = maxVelocity;
            _minVelocity = minVelocity;
            _loops = loops;
            
            Trigger = new TimeTrigger(TriggerUpdateAction, 0.1d, 0, true);
        }

        public void TriggerUpdateAction(int calls) {
            if (_train.CurrentSpeed == 0) {
                _train.CurrentSpeed = 0.5;
            }
            _train.CurrentSpeed += _train.CurrentSpeed * _increaseFactor;

            if (_train.CurrentSpeed >= _maxVelocity && _increaseFactor > 0)
            {
                _train.CurrentSpeed = _maxVelocity;
            }

            if (_train.CurrentSpeed <= _minVelocity && _increaseFactor < 0)
            {
                _train.CurrentSpeed = _minVelocity;
            }
            
        }
        
        public void Translate(SimulationTime simTime, Train train)
        {
            if (_train == null) {
                if (_increaseFactor < 0)
                {
                    train.CurrentSpeed = _maxVelocity;
                }
                else if (_increaseFactor > 0)
                {
                    train.CurrentSpeed = _minVelocity;
                }
            }

            _train = train;

            if (_minVelocity < 0) {
                _minVelocity = _train.CurrentSpeed;
            }

            Trigger.Update(simTime);
        }
    }
}

﻿using MitigramTestAssignment.Domain;
using MitigramTestAssignment.Domain.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace MitigramTestAssignment.Helpers
{
    public static class CommandFactory
    {
        private static Regex _accelerateRegex = new Regex("a(?<target>\\d+)");
        private static Regex _decelerateRegex = new Regex("d(?<target>\\d+)");

        public static ICommand CreateNewCommand(string commandText, ConsoleKey lastKey)
        {
            if (commandText == "s")
            {
                return new StopStartCommand();
            }
            else if (lastKey == ConsoleKey.UpArrow)
            {
                return new AccelerateByCommand(0.2);
            }
            else if (lastKey == ConsoleKey.DownArrow)
            {
                return new DecelerateByCommand(0.2);
            }
            else if (lastKey == ConsoleKey.Enter)
            {
                if (_accelerateRegex.IsMatch(commandText))
                {
                    var match = _accelerateRegex.Match(commandText);
                    return new AccelerateCommand(int.Parse(match.Result("${target}")));
                }
                else if (_decelerateRegex.IsMatch(commandText))
                {
                    var match = _decelerateRegex.Match(commandText);
                    return new DecelerateCommand(int.Parse(match.Result("${target}")));
                }
            }

            return null;
        }
    }
}

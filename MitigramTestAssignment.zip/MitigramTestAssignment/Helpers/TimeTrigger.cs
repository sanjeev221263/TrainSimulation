using System;

namespace MitigramTestAssignment
{
    public class TimeTrigger
    {
        private double _tickRate;
        public int CurrentIndex;
        private double _currentFrameTime;
        private double _startFrame;
        private int _repetitions = 0;
        private int _currentRep;
        private bool _isCompleted;
        private Action<int> _action;
        private Action _completeAction;
        private bool _isStarted;
        
        public bool IsCompleted
        {
            get
            {
                return _isCompleted;
            }
        }

        public bool IsStarted
        {
            get
            {
                return _isStarted;
            }
        }

        public void Start()
        {
            _currentFrameTime = -1;
            _currentRep = 0;
            _isCompleted = false;
            _isStarted = true;
        }

        public void Stop()
        {
            _isCompleted = true;
        }

        public Action CompletedAction
        {
            get
            {
                return _completeAction;
            }
            set
            {
                _completeAction = value;
            }
        }
        
        public void InitializeInstance(Action<int> methodToCall, double secondsBetweenCalls, int repetitions, bool autoStart)
        {
            _action = methodToCall;
            _tickRate = secondsBetweenCalls * 1000;
            _repetitions = repetitions;
            _currentFrameTime = -1;
            _currentRep = 0;
            if (autoStart)
            {
                Start();
            }
        }

        /// <summary>
        ///  Action<int> parameter = milliseconds passed
        /// </summary>
        /// <param name="secondsBetweenCalls"></param>
        /// <param name="repetitions">0 if loop</param>
        public TimeTrigger(Action<int> methodToCall, double secondsBetweenCalls, int repetitions, bool autoStart)
        {
            InitializeInstance(methodToCall, secondsBetweenCalls, repetitions, autoStart);
        }

        public void Update(SimulationTime gameTime)
        {
            if (!_isStarted)
            {
                return;
            }

            if (_isCompleted)
            {
                return;
            }

            if (_currentFrameTime < 0)
            {
                _startFrame = _currentFrameTime = gameTime.Total.TotalMilliseconds;
            }
            else
            {
                if ((gameTime.Total.TotalMilliseconds - _currentFrameTime > _tickRate))
                {
                    _currentFrameTime = gameTime.Total.TotalMilliseconds;
                    if (_repetitions != 0 && _currentRep == _repetitions)
                    {
                        _action.Invoke((int)(gameTime.Total.TotalMilliseconds - _startFrame));
                        if (_completeAction != null)
                        {
                            _completeAction.Invoke();
                        }
                        _isCompleted = true;
                    }
                    else if (_repetitions == 0 || _currentRep < _repetitions)
                    {
                        _action.Invoke((int)(gameTime.Total.TotalMilliseconds - _startFrame));
                    }
                    _currentRep += 1;
                }
            }
        }
    }
}

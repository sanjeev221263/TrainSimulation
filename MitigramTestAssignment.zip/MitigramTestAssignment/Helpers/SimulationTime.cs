﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MitigramTestAssignment
{
    public class SimulationTime
    {
        public TimeSpan Total { get; set; }
    }
}
